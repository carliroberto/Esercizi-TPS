﻿#######################################################################

#Inserimento Valori e Creazione Variabili:

Write-Host "Inserisci il nome utente"

$nomeUtente = Read-Host

Write-Host "Inserisci il primo prodotto del carrello"

$prodotto1 = Read-Host

Write-Host "Inserisci il costo del primo prodotto"

[int]$costoProdotto1 = Read-Host

Write-Host "Inserisci il secondo prodotto del carrello"

$prodotto2 = Read-Host

Write-Host "Inserisci il costo del secondo prodotto"

[int]$costoProdotto2 = Read-Host

Write-Host "Inserisci il terzo prodotto del carrello"

$prodotto3 = Read-Host

Write-Host "Inserisci il costo del terzo prodotto"

[int]$costoProdotto3 = Read-Host

$costoTotaleParziale = $costoProdotto1 + $costoProdotto2 + $costoProdotto3

$simboloEuro = [char][int]0x20ac

$bonus = 20

$messaggio = "Non hai diritto a nessun bonus"

$costoTotale 

#Stampa del risultato:

Write-Host " "
Write-Host "L'ordine eseguito da $nomeUtente, contiene: "
Write-Host " "
Write-Host "- $prodotto1 dal costo di: $costoProdotto1 $simboloEuro,"
Write-Host "- $prodotto2 dal costo di: $costoProdotto2 $simboloEuro,"
Write-Host "- $prodotto3 dal costo di: $costoProdotto3 $simboloEuro."
Write-Host " "
Write-Host "Il costo totale senza bonus ammonta a: $costoTotaleParziale $simboloEuro"

#Controllo bonus:

if($costoTotaleParziale % 2 -eq 0)
    {
    $costoTotale = $costoTotaleParziale + $bonus
    Write-Host "Il costo totale compreso di bonus ammonta a: $costoTotale $simboloEuro"
    }
else
    {Write-Host $messaggio}

#######################################################################
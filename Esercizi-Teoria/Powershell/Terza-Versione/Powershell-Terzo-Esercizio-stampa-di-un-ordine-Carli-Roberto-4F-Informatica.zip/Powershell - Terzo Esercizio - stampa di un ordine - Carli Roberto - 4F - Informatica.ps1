############################################################################################################

#Creazione e Stampa delle informazioni


param(
	[parameter(Mandatory=$true)][string]$nome,
	[parameter(Mandatory=$true)][string]$cognome,
	[parameter(Mandatory=$false)][int]$n1,
	[parameter(Mandatory=$false)][string]$puma,
	[parameter(Mandatory=$false)][int]$n2,
	[parameter(Mandatory=$false)][string]$adidas,
	[parameter(Mandatory=$false)][int]$n3,
	[parameter(Mandatory=$false)][string]$champions
)

write-host "L'ordine di $nome $cognome comprende: $n1 $puma, $n2 $adidas, $n3 $champions"

############################################################################################################
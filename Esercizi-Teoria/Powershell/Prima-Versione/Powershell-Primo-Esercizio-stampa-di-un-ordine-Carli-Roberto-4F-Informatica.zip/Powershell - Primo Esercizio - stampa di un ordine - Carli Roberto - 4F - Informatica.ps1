###########################

#Creazione Variabili

$nome = "Roberto Carli"
$n1 = 5
$puma = "Scarpe Puma"
$n2 = 7
$adidas = "Magliette Adidas"
$n3 = 3
$champions = "Felpe Champions"
$npezzi = $n1 + $n2 + $n3
$corriere = "GLS"
$dataoggi = Get-Date
$dataconsegna = $dataoggi.AddDays(7)

#Concatenazione di stringhe

$concatenazione="Ciao $nome l'ordine da te eseguito, comprende: $n1 paia di $puma, $n2 $adidas, $n3 $champions. Per un totale di $npezzi pezzi in consegna con il corriere: $corriere con raggiungimento del pacco a destinazione in data: $dataconsegna."

#Stampa delle variabili

Write-Output $concatenazione

###########################